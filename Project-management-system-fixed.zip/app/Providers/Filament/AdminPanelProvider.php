<?php

namespace App\Providers\Filament;

use App\Filament\Admin\Pages\Dashboard;
use App\Filament\Admin\Widgets\AdminOverview;
use App\Filament\Auth\Login;
use App\Filament\Pages\Attendance;
use App\Filament\Pages\AttendanceReports;
use App\Filament\Pages\CompanySettings;
use App\Filament\Resources\BranchResource;
use App\Filament\Resources\DepartmentResource;
use App\Filament\Resources\TaskResource;
use App\Filament\Resources\UserResource;
use App\Models\Setting;
use Filament\Http\Middleware\Authenticate;
use Filament\Http\Middleware\AuthenticateSession;
use Filament\Http\Middleware\DisableBladeIconComponents;
use Filament\Http\Middleware\DispatchServingFilamentEvent;
use Filament\Panel;
use Filament\PanelProvider;
use Filament\Support\Colors\Color;
use Filament\View\PanelsRenderHook;
use Illuminate\Cookie\Middleware\AddQueuedCookiesToResponse;
use Illuminate\Cookie\Middleware\EncryptCookies;
use Illuminate\Foundation\Http\Middleware\VerifyCsrfToken;
use Illuminate\Routing\Middleware\SubstituteBindings;
use Illuminate\Session\Middleware\StartSession;
use Illuminate\Support\Facades\Storage;
use Illuminate\View\Middleware\ShareErrorsFromSession;

class AdminPanelProvider extends PanelProvider
{
    public function panel(Panel $panel): Panel
    {
        return $panel
            ->default()
            ->id('admin')
            ->path('admin')
            ->login(Login::class)
            ->authGuard('admin')
            ->brandName(fn (): string => Setting::current()->company_name ?: 'Project Management System')
            ->brandLogo(fn (): ?string => Setting::current()->company_logo
                ? Storage::disk('public')->url(Setting::current()->company_logo)
                : null)
            ->colors(['primary' => Color::hex(Setting::current()->primary_color ?: '#2563EB')])
            ->resources([
                BranchResource::class,
                DepartmentResource::class,
                TaskResource::class,
                UserResource::class,
            ])
            ->pages([
                Dashboard::class,
                Attendance::class,
                AttendanceReports::class,
                CompanySettings::class,
            ])
            ->widgets([
                AdminOverview::class,
            ])
            ->renderHook(PanelsRenderHook::HEAD_END, fn (): string => view('filament.theme')->render())
            ->renderHook(PanelsRenderHook::BODY_START, fn (): string => view('filament.product-shell')->render())
            ->middleware([
                EncryptCookies::class,
                AddQueuedCookiesToResponse::class,
                StartSession::class,
                AuthenticateSession::class,
                ShareErrorsFromSession::class,
                VerifyCsrfToken::class,
                SubstituteBindings::class,
                DisableBladeIconComponents::class,
                DispatchServingFilamentEvent::class,
            ])
            ->authMiddleware([
                Authenticate::class,
            ]);
    }
}
